
# DEFINE seg-areas
SEGMENT_CLASSES = {
    0 : 'NOT tumor',
    1 : 'NECROTIC/CORE', # or NON-ENHANCING tumor CORE
    2 : 'EDEMA',
    3 : 'ENHANCING'
}

# there are 155 slices per volume
# to start at 5 and use 145 slices means we will skip the first 5 and last 5
VOLUME_SLICES = 100
VOLUME_START_AT = 22 # first slice of volume that we will include

TRAIN_DATASET_PATH = 'Dataset/BraTS2020_TrainingData/MICCAI_BraTS2020_TrainingData/'
VALIDATION_DATASET_PATH = 'Dataset/BraTS2020_ValidationData/MICCAI_BraTS2020_ValidationData'

IMG_SIZE=64
NUM_CLASSES = 4
BATCH_SIZE = 1
N_CHANNELS = 2

PLOT = True

EPOCHS = 35
MODEL_SAVE_NAME = "model_v1.h5"
MIN_LR=0.000001
LR = 0.001

