import os
import cv2
import glob
import PIL
import shutil
import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from PIL import Image, ImageOps
#!pip install git+https://github.com/miykael/gif_your_nifti # nifti to gif

# ml libs
import keras
import keras.backend as K
from keras.callbacks import CSVLogger
import tensorflow as tf
from tensorflow.keras.utils import plot_model
from tensorflow.keras.models import *
from tensorflow.keras.layers import *
from tensorflow.keras.optimizers import *
from tensorflow.keras.callbacks import ModelCheckpoint, ReduceLROnPlateau, EarlyStopping, TensorBoard

from getData import get_data
from datagenerator import DataGenerator
from model_build import build_unet
from config import *
from utils import *
import warnings
warnings.filterwarnings('ignore')

# Make numpy printouts easier to read.
np.set_printoptions(precision=3, suppress=True)


if __name__ == "__main__":
    # get the data
    train_ids, val_ids, test_ids = get_data()

    # build model
    input_layer = Input((IMG_SIZE, IMG_SIZE, 2))

    model = build_unet(input_layer, 'he_normal', 0.2)
    model.compile(loss="categorical_crossentropy", optimizer=keras.optimizers.Adam(learning_rate=LR),
                  metrics=['accuracy', tf.keras.metrics.MeanIoU(num_classes=NUM_CLASSES), dice_coef, precision, sensitivity,
                           specificity, dice_coef_necrotic, dice_coef_edema, dice_coef_enhancing])

    if PLOT:
        plot_model(model,
                   show_shapes=True,
                   show_dtype=False,
                   show_layer_names=True,
                   rankdir='TB',
                   expand_nested=False,
                   dpi=70)
    # make data generator
    K.clear_session()
    training_generator = DataGenerator(train_ids)
    valid_generator = DataGenerator(val_ids)
    test_generator = DataGenerator(test_ids)

    #show data distribution
    showDataLayout(train_ids, val_ids, test_ids)

    csv_logger = CSVLogger('training.log', separator=',', append=False)

    callbacks = [
        #     keras.callbacks.EarlyStopping(monitor='loss', min_delta=0,
        #                               patience=2, verbose=1, mode='auto'),
        keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.2,
                                          patience=2, min_lr=MIN_LR, verbose=1),
        #  keras.callbacks.ModelCheckpoint(filepath = 'model_.{epoch:02d}-{val_loss:.6f}.m5',
        #                             verbose=1, save_best_only=True, save_weights_only = True)
        csv_logger]


    print("#" * 25, " -TRAINING STARTING- ", "#" * 25)
    history = model.fit(training_generator,
                        epochs=EPOCHS,
                        steps_per_epoch=len(train_ids),
                        callbacks=callbacks,
                        validation_data=valid_generator
                        )
    model.save(MODEL_SAVE_NAME)

    print("#"*25," -TRAINING COMPLETED- ","#"*25)





