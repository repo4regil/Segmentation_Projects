# Analyze training log file using graphs after completing Training process
import keras
import tensorflow as tf
import pandas as pd
import matplotlib.pyplot as plt
from config import *

def train_analysis():


    # read training log file
    history = pd.read_csv('training.log', sep=',', engine='python')

    hist = history

    # hist=history.history

    acc=hist['accuracy']
    val_acc=hist['val_accuracy']

    epoch=range(len(acc))

    loss=hist['loss']
    val_loss=hist['val_loss']

    train_dice=hist['dice_coef']
    val_dice=hist['val_dice_coef']

    f,ax=plt.subplots(1,4,figsize=(16,8))

    ax[0].plot(epoch,acc,'b',label='Training Accuracy')
    ax[0].plot(epoch,val_acc,'r',label='Validation Accuracy')
    ax[0].legend()

    ax[1].plot(epoch,loss,'b',label='Training Loss')
    ax[1].plot(epoch,val_loss,'r',label='Validation Loss')
    ax[1].legend()

    ax[2].plot(epoch,train_dice,'b',label='Training dice coef')
    ax[2].plot(epoch,val_dice,'r',label='Validation dice coef')
    ax[2].legend()

    ax[3].plot(epoch,hist['mean_io_u'],'b',label='Training mean IOU')
    ax[3].plot(epoch,hist['val_mean_io_u'],'r',label='Validation mean IOU')
    ax[3].legend()

    plt.show()
train_analysis()